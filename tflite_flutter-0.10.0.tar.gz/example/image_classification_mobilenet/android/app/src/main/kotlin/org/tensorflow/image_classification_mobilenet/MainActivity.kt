package org.tensorflow.image_classification_mobilenet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

package org.tensorflow.style_transfer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

package org.tensorflow.super_resolution_esrgan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

# Text Classification Example 

Refer to [Medium Blog](https://medium.com/@am15hg/text-classification-using-tensorflow-lite-plugin-for-flutter-3b92f6655982) for detailed tutorial.

### Overview

This basic Text Classification app demonstrates the usage of tflite_flutter_plugin.

![DEMO GIF](demo.gif)
